Placeholder that ensures the project has a server/lib directory in git that may be installed into via pip.
